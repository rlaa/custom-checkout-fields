<?php
namespace Test\Module\Setup;

use Magento\Framework\Module\Setup\Migration;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Model\AttributeRepository;

/**
* @codeCoverageIgnore
*/
class InstallData implements InstallDataInterface
{

                private $customerSetupFactory;

                public function __construct(\Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory)
                {
                        $this->customerSetupFactory = $customerSetupFactory;
                }


                public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
                {

                        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

                        $setup->startSetup();

                        // insert attribute
                        $customerSetup->addAttribute('customer_address', 'custom_test',  [
                                'label' => 'Custom Test',
                                'type' => 'varchar',
                                'input' => 'text',
                                'position' => 45,
                                'visible' => true,
                                'required' => false,
                                'system' => 0
                        ]);

                        $customerSetup->getEavConfig()->getAttribute('customer_address', 'custom_test')
                                      ->setData('used_in_forms',['adminhtml_customer_address', 'customer_address_edit', 'customer_register_address'])
                                      ->save();

                        $setup->endSetup();
                }
}